// import { useUserAuth } from "../Context/UserAuthContext";

import { useUserAuth } from "../../Context/UserAuthContext";
import {fireEvent, getByTestId, render, screen,waitFor} from "@testing-library/react";

import userEvent from "@testing-library/user-event";

import Login,{ validateEmail } from "../Login";
import { BrowserRouter } from 'react-router-dom';


jest.mock("../../Context/UserAuthContext", () => ({
    useUserAuth: () => ({
      logIn: jest.fn(),
      googleSignIn: jest.fn(),
    }),
  }));


describe("Test the Login Component",() => {

    test("render the login form with 3 buttons",async () => {
        render(
            <BrowserRouter>
            <Login />
            </BrowserRouter>
            );
        const buttonList =await screen.findAllByRole("button");
        expect(buttonList).toHaveLength(3);
    });

  

    test("should fail on email validation", () => {
        const testEmail = "test.com";
        expect(validateEmail(testEmail)).not.toBe(true);
    })

    test("email input field should accept email", () => {
        render(
            <BrowserRouter>
            <Login />
            </BrowserRouter>
            );
        const email = screen.getByPlaceholderText("Email address");
        userEvent.type(email,"test");
        expect(email.value).not.toMatch("test1234@gmail.com");
    })

    test("password input field should have type password", () =>{
        render(
            <BrowserRouter>
            <Login />
            </BrowserRouter>
            );

         const password = screen.getByPlaceholderText("Password");
         expect(password).toHaveAttribute("type","password");   
    })

    test("should be able to submit the form",async ()=>{
        render(
            <BrowserRouter>
            <Login />
            </BrowserRouter>
            );
        const submitBtn = screen.getByTestId("submit");
        const emailInput = screen.getByPlaceholderText("Email address");
        const passwordInput = screen.getByPlaceholderText("Password");    
        userEvent.type(emailInput,"test1234@gmail.com");
        userEvent.type(passwordInput,"1234567");
        userEvent.click(submitBtn);
        await waitFor(() => {
            expect(window.location.pathname).toBe("/home");
          });

            
    })






});