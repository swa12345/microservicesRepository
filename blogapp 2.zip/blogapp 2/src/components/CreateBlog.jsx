import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import Header from './Header';

const CreateBlog = ({ onAddBlog }) => {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");

  const submitForm = (e) => {
    e.preventDefault();
    const user = { id: 1, name: 'John Doe' };

    const newBlog = {
      id: Date.now(),
      title: title,
      body: body,
      date: new Date().toISOString(),

    };

    onAddBlog(newBlog);
    console.log(newBlog);

    setTitle('');
    setBody('');

  };

  return (
    <>
      <Header />
      <div className="container mt-4">
        {
          <><h1 className="h1 text-center">Create a New Post</h1><form onSubmit={submitForm} className="container">

            <div>
              <div className="mb-3">
                <label htmlFor="title" className="form-label">Title</label>
                <input type="text" className="form-control" id="title" name="title" autoComplete='off'
                  value={title} onChange={(e) => setTitle(e.target.value)} />
              </div>
              <div className="mb-3">
                <label htmlFor="body" id="body" autoComplete="off"

                  className="form-label">Body</label>
                <textarea value={body} onChange={(e1) => setBody(e1.target.value)} className="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
              </div>

              <button type="submit" className="btn btn-success">Create Post</button>
            </div>

          </form>
          </>

        }
      </ div>
    </>
  )
}

export default CreateBlog;
