// BlogList.js
import React, { useEffect, useState } from 'react';
import { Link, Route, Router } from 'react-router-dom';
import './BlogList.css';
import Header from './Header';
import { Container, Row, Col, Form } from 'react-bootstrap';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';

const BlogLists = () => {
  const [blogPosts, setBlogPosts] = useState([]);
  const searchParam = new URLSearchParams(window.location.search);
  console.log('*******************', searchParam.get('userId'));
  console.log('*******post********', searchParam.get('postId'));
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => setBlogPosts(data))
      .catch(error => console.log(error));
  }, []);

  //   ++++++++++++++++++++++++++

  //   const postByUserIdandPostIdUrl=`https://jsonplaceholder.typicode.com/users/${userId}/posts?id=${postId}`

  //excel file download
  const handleFileExport = ()=>{
    // console.log(blogDetails);
    var wb = XLSX.utils.book_new(),
    ws = XLSX.utils.json_to_sheet(blogPosts);
    XLSX.utils.book_append_sheet(wb,ws,"blogPosts")
    XLSX.writeFile(wb,"blogPosts.xlsx");
  }


  //zip file download
  const downloadZipFile = async () => {
    const zip = new JSZip();

    const folder = zip.folder('blogPosts');

    blogPosts.forEach((item) => {
      const textData = JSON.stringify(item); 
      folder.file(`${item.id}.json`, textData);
    });

    const zipBlob = await zip.generateAsync({ type: 'blob' });

    saveAs(zipBlob, 'data.zip');
  }

  return (
    <>
      <Header />

      <div>
        <Container>
          <Row className="mt-4">
            <Col>
            <button type="button" class="btn btn-secondary mt-2 ml-auto" onClick={handleFileExport}>Export</button><br />
            <button type="button" class="btn btn-secondary mt-2 ml-auto" onClick={downloadZipFile}>Download Zip</button>
              <h2 className="text-center">Blog Posts</h2>
            </Col>
          </Row>
          <Row className="mt-4">
            <Col>
              <ul className="list-group">
                {blogPosts.map((post) => (
                  <li key={post.id} className="list-group-item">
                    <Link className="text-decoration-none" to={`/blogDetails?postId=${post.id}&userId=${post.userId}`}>{post.title}</Link><br />
                  </li>
                ))}
              </ul>

              
            </Col>
          </Row>
        </Container>
      </div>
    </>

  );

};

export default BlogLists;
