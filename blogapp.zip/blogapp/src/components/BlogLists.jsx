// BlogList.js
import React, { useEffect, useState } from 'react';
import { Link, Route, Router } from 'react-router-dom';
import './BlogList.css';
import Header from './Header';

const BlogLists = () => {
  const [blogPosts, setBlogPosts] = useState([]);
  const searchParam = new URLSearchParams(window.location.search);
  console.log('*******************',searchParam.get('userId'));
  console.log('*******post********',searchParam.get('postId'));
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/posts')
      .then(response => response.json())
      .then(data => setBlogPosts(data))
      .catch(error => console.log(error));
  }, []);

//   ++++++++++++++++++++++++++

//   const postByUserIdandPostIdUrl=`https://jsonplaceholder.typicode.com/users/${userId}/posts?id=${postId}`

 

  return (
    <>   
    <Header />
     <div className='container'>
      <h1>Blog Posts</h1>
      {blogPosts.map(post => (
        <div key={post.id} className='link'>
          <Link className="text-decoration-none" to={`/blogDetails?postId=${post.id}&userId=${post.userId}`}>{post.title}</Link><br />
          {/* <a href="#" class="text-decoration-none">This link has its text decoration removed</a> */}
        </div>
      ))}
    </div>
    </>

  );
  
};

export default BlogLists;
