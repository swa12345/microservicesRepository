import React, { useEffect, useState } from 'react';
import { Link, Route, Router } from 'react-router-dom';
import './BlogDetails.css';
import CommentForm from './CommentForm';
import { Container, Row, Col, Form, Button } from 'react-bootstrap';
import Header from './Header';
import * as XLSX from 'xlsx';


const BlogDetails = () => {
  const [blogDetails, setBlogDetails] = useState([]);
  const [userDetails, setUserDetails] = useState({ name: '', email: '', website: '' });
  const [postComments, setPostComments] = useState([]);
  const searchParam = new URLSearchParams(window.location.search);
  const userId = searchParam.get('userId');
  const postId = searchParam.get('postId');
  console.log('*******************', searchParam.get('userId'));
  console.log('*******post1********', searchParam.get('postId'));


  useEffect(() => {
    fetch(`https://jsonplaceholder.typicode.com/users/${userId}/posts?id=${postId}`)
      .then(response => response.json())
      .then(data => console.log(setBlogDetails(data)))
      .catch(error => console.log(error));

    fetch(`https://jsonplaceholder.typicode.com/users/${userId}`)

      .then(response => response.json())
      .then(data => console.log(setUserDetails(data)))
      .catch(error => console.log(error));

    // fetch(`https://jsonplaceholder.typicode.com/posts/${postId}/comments`)
    //   .then(response => response.json())
    //   .then(data => console.log(setPostComments(data)))
    //   .catch(error => console.log(error));

    const storedComments = JSON.parse(localStorage.getItem(`comments_${postId}`) || '[]');
    setPostComments(storedComments);
  }, []);

  const handleAddComment = (newComment) => {
    const updatedComments = [...postComments, newComment];
    localStorage.setItem(`comments_${postId}`, JSON.stringify(updatedComments));
    setPostComments(updatedComments);
  };

  const handleFileExport = ()=>{
    console.log(blogDetails);
    var wb = XLSX.utils.book_new(),
    ws = XLSX.utils.json_to_sheet(blogDetails);
    XLSX.utils.book_append_sheet(wb,ws,"blogDetails")
    XLSX.writeFile(wb,"blogDetails.xlsx");
  }

  return (
    <>

      <Header />

      <Container>
        <Row className="mt-4">
          <Col>
          <button type="button" class="btn btn-secondary mt-2 ml-auto" onClick={handleFileExport}>Export</button>
            <h2 className="text-center">Blog Details</h2>
          </Col>
        </Row>
        <Row className="mt-4">
          <Col>
            <ul className="list-group">
              {blogDetails.map((post) => (
                <li key={post.id} className="list-group-item">
                  <p>{post.body}</p>
                </li>
              ))}
            </ul>
          </Col>
        </Row>
      </Container>

      <Container>
        <Row className="mt-4">
          <Col>
            <h2 className="text-center">Blog Created by</h2>
          </Col>
        </Row>
        <Row className="mt-4">
          <Col>
            <ul className="list-group">
              <li className="list-group-item">
                <p>{userDetails.name}</p>
                <p>{userDetails.email}</p>
                <p>References - {userDetails.website}</p>
              </li>
            </ul>
          </Col>
        </Row>
      </Container>

      <Container>
        <Row className="mt-4">
          <Col>
            <h2 className="text-center">Comments</h2>
          </Col>
        </Row>
        <Row className="mt-4">
          <Col>
            <ul className="list-group">
              {postComments.map((comments) => (
                <li key={comments.id} className="list-group-item">
                  <p>{comments.body}</p>
                </li>
              ))}
            </ul>
          </Col>
        </Row>
      </Container>

      <CommentForm onAddComment={handleAddComment} />

    </>

  );
};

export default BlogDetails;