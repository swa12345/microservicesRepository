import React, { useState, useEffect } from 'react';
import CreateBlog from './CreateBlog';
// import BlogLists from './BlogLists';
import BlogList from './BlogList';
import { Navigate } from 'react-router-dom';


const ViewMyBlog = () => {
  const initialBlogs = JSON.parse(localStorage.getItem('blogs')) || [];
  const [blogs, setBlogs] = useState(initialBlogs);

  // Save the blog data to localStorage whenever the blogs state changes
  useEffect(() => {
    localStorage.setItem('blogs', JSON.stringify(blogs));
  }, [blogs]);

  // Function to add a new blog to the state
  const handleAddBlog = (newBlog) => {
    setBlogs((prevBlogs) => [...prevBlogs, newBlog]);
  };

  // Function to delete a blog from the state
  const handleDeleteBlog = (blogId) => {
    setBlogs((prevBlogs) => prevBlogs.filter((blog) => blog.id !== blogId));
  };

  return (
    <>
    <div>
      <CreateBlog onAddBlog={handleAddBlog} />
      
    </div>
    {/* <div>
        <BlogList blogs={blogs} onDeleteBlog={handleDeleteBlog} />
    </div> */}
    </>
  );
};

export default ViewMyBlog;
