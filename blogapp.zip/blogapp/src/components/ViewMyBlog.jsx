import React, { useState, useEffect } from 'react';
import CreateBlog from './CreateBlog';
import BlogList from './BlogList';
import { Link } from 'react-router-dom';


const ViewMyBlog = () => {
  const initialBlogs = JSON.parse(localStorage.getItem('blogs')) || [];
  const [blogs, setBlogs] = useState(initialBlogs);
  const [dataFromLocalStorage,setDataFromLocalStorage] = useState(null)

  useEffect(() => {

    localStorage.setItem('blogs', JSON.stringify(blogs));
  }, [blogs]);

  const handleAddBlog = (newBlog) => {
    setBlogs((prevBlogs) => [...prevBlogs, newBlog]);
  };

  const handleDeleteBlog = (blogId) => {
    setBlogs((prevBlogs) => prevBlogs.filter((blog) => blog.id !== blogId));
  };

  return (
    <>
    <div>
      <CreateBlog onAddBlog={handleAddBlog} />
    </div>
    <div>
        <BlogList blogs={blogs} onDeleteBlog={handleDeleteBlog} />
    </div>
    </>
  );
};

export default ViewMyBlog;
