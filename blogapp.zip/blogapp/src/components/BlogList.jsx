import React from 'react';

const BlogList = ({ blogs, onDeleteBlog }) => {
  return (
    <div>
      <h2>My Blogs</h2>
      {blogs.map((blog) => (
        <div key={blog.id}>
          <h3>{blog.title}</h3>
          <p>{blog.body}</p>
          <p>By: {blog.author}</p>
          <p>Date: {blog.date}</p>
          <button onClick={() => onDeleteBlog(blog.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
};

export default BlogList;
