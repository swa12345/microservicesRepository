import React from 'react';
import { Container, Row, Col, Form } from 'react-bootstrap';

const BlogList = ({ blogs, onDeleteBlog }) => {
  return (
    <>

      <Container>
        <Row className="mt-4">
          <Col>
            <h2 className="text-center">My Blogs</h2>
          </Col>
        </Row>
        <Row className="mt-4">
          <Col>
            <ul className="list-group">
              {blogs.map((item) => (
                <li key={item.id} className="list-group-item">
                  <h4>{item.title}</h4>
                  <p>{item.body}</p>
                  <p>Date: {item.date}</p>
                  <button type="button" class="btn btn-primary" onClick={() => onDeleteBlog(item.id)}>Delete</button>
                </li>
              ))}
            </ul>
          </Col>
        </Row>
      </Container>
    </>
  );
};

export default BlogList;
