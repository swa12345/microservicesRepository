// import React from 'react';
// import { useSelector } from 'react-redux';

// const ViewMyBlogs = () => {
//   const posts = useSelector((state) => state.posts);
//   console.log(posts.title);

//   return (
//     <div>
//       {/* {posts.map((post,index) => ( */}
//         <div>
//           <p>{posts[0].title}</p>
//         </div>
//     {/* ))} */}
//     </div>
//   );
// };

// export default ViewMyBlogs;
