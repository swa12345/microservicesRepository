// import React from 'react';

// const ChildComponent = (props) => {
//   return (
//     <div>
//       <p>{props.message}</p>
//     </div>
//   );
// };

// export default ChildComponent;
