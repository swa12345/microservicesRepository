// // ProtectedRoute.js
// import React from 'react';
// import { Route, Navigate } from 'react-router-dom';
// import { useAuth } from '../firebase/firebaseConfig'; // Import your Firebase authentication hook

// const ProtectedRoute = ({ component: Component, ...rest }) => {
//   const { currentUser } = useAuth(); // Use the Firebase authentication hook to get the current user

//   return (
//     <Route
//       {...rest}
//       render={(props) =>
//         currentUser ? <Component {...props} /> : <Navigate to="/signIn" />
//       }
//     />
//   );
// };

// export default ProtectedRoute;
