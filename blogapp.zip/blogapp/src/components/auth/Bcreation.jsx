
// import React, { useEffect, useState } from 'react';
// import { dataRef } from '../firebase'; 
// import ChildComponent from './ChildComponent';

// const Bcreation = () => {
//     const [name,setName]=useState('')
//     const [age,setAge] = useState('')
//     const [allValue,setAllValue]=useState({})
//     // const [allValue,setAllValue]=useState([])
//     const handleAdd=()=>{
//         if(name!=="" && age!=="") {
//             dataRef.ref().child("all").push(name).push(age);
//         setName("")
//         }
        
//     }

//     useEffect(()=>{
//         dataRef.ref().child("all").on('value',data=>{
//             const getdata=Object.values(data.val())
//             setAllValue(getdata)
//         })
//     },[])
//     console.log(allValue);

//   return (
//     <div>
//         <input value={name} onChange={(e)=>{setName(e.target.value)}} />
//         <input value={age} onChange={(e)=>{setAge(e.target.value)}} />
//         <button onClick={handleAdd}>Add</button>
//         <div>
//             {allValue.map((valData,i)=><h1 key={i}>{valData}</h1>)}
//             <ChildComponent message={allValue} />
//         </div>
//     </div>
//   )
// }

// export default Bcreation;
