// import { signInWithEmailAndPassword } from "firebase/auth";
// import React, { useState } from "react";
// import { auth } from "../../firebase";
// import { Link } from "react-router-dom";
// import { useNavigate } from 'react-router-dom';
// import './SignIn.css';

// const SignIn = () => {
//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const navigate = useNavigate();

//   const signIn = (e) => {
//     e.preventDefault();
//     signInWithEmailAndPassword(auth, email, password)
//       .then((userCredential) => {
//         console.log(userCredential);
//         navigate('/home');
//       })
//       .catch((error) => {
//         console.log(error);
//       });
//   };

//   // return (
//   //   <div className="sign-in-container">
//   //     <form onSubmit={signIn}>
//   //       <h1>Log In to your Account</h1>
//   //       <div className="email-wrapper-div"> <div className="label">Enter Email </div>          :
//   //       <div><input className="input"
//   //         type="email"
//   //         placeholder="Enter your email"
//   //         value={email}
//   //         onChange={(e) => setEmail(e.target.value)}
//   //       ></input></div></div>
//   //       <div><div className="label">Enter Password: </div>
//   //       <div><input className="input"
//   //         type="password"
//   //         placeholder="Enter your password"
//   //         value={password}
//   //         onChange={(e) => setPassword(e.target.value)}
//   //       ></input></div></div>
//   //       <button className="button" type="submit">Log In</button>
//   //     </form>
//   //     <Link to="/signUp">New User</Link>
//   //   </div>
//   // );

//   return (
//     <div className="container">
//       <div className="row justify-content-center mt-5">
//         <div className="col-md-6">

//       <form onSubmit={signIn}>
//         <h1>Log In to your Account</h1>

//         <div className="form-group">Enter Email        :
//         <input className="form-control"
//           type="email"
//           placeholder="Enter your email"
//           value={email}
//           onChange={(e) => setEmail(e.target.value)}>
//         </input>
//         </div>   

//           <div className="form-group">Enter Password
//           <input className="form-control"
//           type="password"
//           placeholder="Enter your password"
//           value={password}
//           onChange={(e) => setPassword(e.target.value)}>
//           </input>
//         </div>

//         <div className="row justify-content-center">
//         <div className="col-auto" >
//         <button className="btn btn-primary container mt-4" type="submit">Log In</button>
//         </div>
//         </div>
//       </form>
//       <Link to="/signUp">New User</Link>
//     </div>
//     </div>
//     </div>
//   );
// };

// export default SignIn;