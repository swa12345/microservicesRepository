import React, { useState } from 'react';
import { Container, Row, Col, Form } from 'react-bootstrap';

const CommentForm = ({ onAddComment }) => {
  const [comment, setComment] = useState('');

  const handleCommentChange = (e) => {
    setComment(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const user = { id: 1, name: 'John Doe' };

    // Create a new comment object
    const newComment = {
      id: Date.now(),
      body: comment,
      name: user.name,
      email: 'john.doe@example.com',
    };

    onAddComment(newComment);

    setComment('');
  };

  return (
    <>
      <div>
        <Container>
          <Row className="mt-4">
            <Col>
              <h2 className="text-center">Add Your Comments</h2>
            </Col>
          </Row>
          <Row className="mt-4">
            <Col>


              <form onSubmit={handleSubmit}>
                <input type="text" id="inputPassword5" class="form-control" aria-describedby="passwordHelpBlock" value={comment}
                  onChange={handleCommentChange} /><br />
                <button type="submit" className="btn btn-success text-center">Post Comments</button>
                <div id="passwordHelpBlock" className="form-text">
                </div>

              </form>
            </Col>
          </Row>
        </Container>
      </div>
    </>
  );
};

export default CommentForm;
