import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Nav, Navbar } from "react-bootstrap"
import { useNavigate } from "react-router";
import { useUserAuth } from "../Context/UserAuthContext";
// import Header from "./Header";

const Header = () => {
  const { logOut, user } = useUserAuth();
  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      await logOut();
      navigate("/");
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <header>
      {/* <nav className="navbar navbar-expand-lg navbar-light bg-light">
  <div className="container-fluid">
    <a className="navbar-brand" href="#">Blogs</a>
    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span className="navbar-toggler-icon"></span>
    </button>
    <div className="collapse navbar-collapse" id="navbarNav">
      <ul className="navbar-nav">
        <li className="nav-item">
          <a className="nav-link active" aria-current="page" href="/Home">Home</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="/createMyBlogs">Create a Blog</a>
        </li>
        <li className="nav-item">
          <a className="nav-link" href="/viewMyBlogs">View My Blog</a>
        </li>

        <li className="nav-item">
          <a className="nav-link" href="/blogs">View All Blogs</a>
        </li>

        <li className="nav-item">
        Hello Welcome <br />
        {user && user.email}
        <Button variant="primary" onClick={handleLogout}>
          Log out
        </Button>
        </li>
      </ul>
    </div>
  </div>
     
</nav> */}

<Navbar bg="light" expand="lg">
      <div className="container d-flex justify-content-between align-items-center">
        {/* Left side of the navbar */}
        <Navbar.Brand href="/Home">Blogs</Navbar.Brand>
        <Nav className="mr-auto">
          {/* Add your Nav links here */}
          <Nav.Link href="/Home">Home</Nav.Link>
          <Nav.Link href="/createMyBlogs">Create a Blog</Nav.Link>
          <Nav.Link href="/viewMyBlogs">View My Blog</Nav.Link>
          <Nav.Link href="/blogs">View All Blogs</Nav.Link>
        </Nav>

        {/* Right side of the navbar */}
        <div className="ml-auto">
        Hello Welcome{" "}
        <b>{user && user.email}</b>{" "}
          {/* Add your logout button here */}
          <Button variant="outline-danger" onClick={handleLogout}>Logout</Button>
        </div>
      </div>
    </Navbar>
    </header>
  );
};

export default Header;
