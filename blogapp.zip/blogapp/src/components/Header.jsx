import React from 'react';
import { Link } from 'react-router-dom';
import { Button, Nav, Navbar } from "react-bootstrap"
import { useNavigate } from "react-router";
import { useUserAuth } from "../Context/UserAuthContext";

const Header = () => {
  const { logOut, user } = useUserAuth();
  const navigate = useNavigate();
  const handleLogout = async () => {
    try {
      await logOut();
      navigate("/");
    } catch (error) {
      console.log(error.message);
    }
  };

  return (
    <header>

      <Navbar bg="light" expand="lg">
        <div className="container d-flex justify-content-between align-items-center">
          <Navbar.Brand href="/Home">Blogs</Navbar.Brand>
          <Nav className="mr-auto">
            <Nav.Link href="/home">Home</Nav.Link>
            <Nav.Link href="/blogs">View All Blogs</Nav.Link>
          </Nav>
          <div className="ml-auto">
            Hello Welcome{" "}
            <b>{user && user.email}</b>{" "}
            <Button variant="outline-danger" onClick={handleLogout}>Logout</Button>
          </div>
        </div>
      </Navbar>
    </header>
  );
};

export default Header;
