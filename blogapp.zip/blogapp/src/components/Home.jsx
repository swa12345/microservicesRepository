import React from "react";
import { Button } from "react-bootstrap"
import { useNavigate } from "react-router";
import { useUserAuth } from "../Context/UserAuthContext";
import Header from "./Header";

const Home = () => {

  return (
    <Header />
  )
};

export default Home;