export const addPost = (post) => {
    console.log("++++++++",post);
    return {
      type: 'ADD_POST',
      payload: post,
    };
  };