import 'bootstrap/dist/css/bootstrap.min.css';
import { Container, Row, Col } from "react-bootstrap";
import { Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./components/Home";
import Login from "./components/Login";
import Signup from "./components/SignUp";
import ProtectedRoute from "./components/ProtectedRoute";
import { UserAuthContextProvider } from "./Context/UserAuthContext";
import BlogLists from './components/BlogLists';
import BlogDetails from "./components/BlogDetails";
import CommentForm from "./components/CommentForm";
import CreateBlog from "./components/CreateBlog";
import ViewMyBlog from './components/ViewMyBlog';
import BlogList from './components/BlogList';


function App() {

  const postId = 1;
  return (
    <>

      <Row>
        <Col>
          <UserAuthContextProvider>
            <Routes>
              <Route
                path="/home"
                element={
                  <ProtectedRoute>
                    <Home />
                    <ViewMyBlog />
                  </ProtectedRoute>
                }
              />
              <Route path="/" element={<Login />} />
              <Route path="/signup" element={<Signup />} />
              <Route path="/blogs" element={<BlogLists />} />
              <Route path="/comments" element={<CommentForm />} />
              <Route path="/blogDetails" element={<BlogDetails />} />
              <Route path="/createMyBlogs" element={<ViewMyBlog />} />
            </Routes>
          </UserAuthContextProvider>
        </Col>
      </Row>
    </>
  );

}
export default App;